#!/usr/bin/env python3
"""
leaky_bucket_shaper.py — Part D (Optional): Implement Leaky Bucket ด้วย Python
ทำเฉพาะกลุ่มที่ได้ algorithm: leaky_bucket จาก generate_group_params.py

*** TODO: แทนค่า drain_rate_pps / bucket_capacity ในบล็อก __main__
    ด้วยค่าที่แปลงจาก token_rate_kbit / bucket_size_kbit ของกลุ่มตนเอง ***
"""
import time
import threading
import queue


class LeakyBucket:
    def __init__(self, drain_rate_pps, bucket_capacity):
        """
        drain_rate_pps: อัตราการปล่อย packet ออก (packet/sec)
        bucket_capacity: ขนาด buffer สูงสุด (packet)
        """
        self.drain_rate = drain_rate_pps
        self.capacity = bucket_capacity
        self.buffer = queue.Queue(maxsize=bucket_capacity)
        self.dropped = 0
        self.sent = 0
        self._running = True

    def add_packet(self, packet):
        try:
            self.buffer.put_nowait(packet)
        except queue.Full:
            self.dropped += 1
            print(f'[DROP] Buffer เต็ม, packet ถูกทิ้ง (total dropped: {self.dropped})')

    def start_draining(self, output_callback):
        interval = 1.0 / self.drain_rate

        def drain_loop():
            while self._running:
                try:
                    packet = self.buffer.get(timeout=interval)
                    output_callback(packet)
                    self.sent += 1
                except queue.Empty:
                    pass
                time.sleep(interval)

        threading.Thread(target=drain_loop, daemon=True).start()

    def stop(self):
        self._running = False


if __name__ == '__main__':
    def output(pkt):
        print(f'[SEND @ {time.time():.3f}] {pkt}')

    # TODO: แทนค่าด้วย parameter ของกลุ่ม (แปลงจาก token_rate_kbit / bucket_size_kbit)
    DRAIN_RATE_PPS = None    # <<< TODO
    BUCKET_CAPACITY = None   # <<< TODO

    if None in (DRAIN_RATE_PPS, BUCKET_CAPACITY):
        raise SystemExit(
            "กรุณาแทนค่า DRAIN_RATE_PPS / BUCKET_CAPACITY ก่อนรัน "
            "(คำนวณจาก token_rate_kbit / bucket_size_kbit ของกลุ่มตนเอง)"
        )

    bucket = LeakyBucket(drain_rate_pps=DRAIN_RATE_PPS, bucket_capacity=BUCKET_CAPACITY)
    bucket.start_draining(output)

    # จำลอง bursty input
    for i in range(50):
        bucket.add_packet(f'packet-{i}')
        time.sleep(0.01)  # burst เร็วกว่า drain rate มาก

    time.sleep(5)
    bucket.stop()
    print(f'\nสรุป: ส่งสำเร็จ {bucket.sent}, ถูกทิ้ง {bucket.dropped}')
