# Lab 14 — คำสั่งอ้างอิง (Traffic Shaping: Token Bucket / Leaky Bucket)

## 0) ติดตั้งเครื่องมือ
```
sudo apt update
sudo apt install -y mininet python3-scapy tcpdump wireshark iproute2
```

## 1) หาค่า parameter ของกลุ่ม (ทำก่อนทุกอย่าง)
```
python3 generate_group_params.py <รหัสกลุ่ม>          # เช่น G07
```
บันทึกค่าทั้งหมดที่ได้ลงตาราง (ใช้ในรายงาน Part การกำหนดค่า Parameter) แล้วนำไปแทนใน:
- `topo_bucket.py` → `BANDWIDTH`
- `generate_burst_traffic.py` → `BURST_SIZE`, `PACKET_SIZE`, `INTERVAL_MS`
- คำสั่ง `tc` ด้านล่าง → `rate`, `burst`, `latency`
- (ถ้าได้ leaky_bucket) `leaky_bucket_shaper.py` → `DRAIN_RATE_PPS`, `BUCKET_CAPACITY`

## 2) รัน Topology (Part A)
```
sudo python3 topo_bucket.py
mininet> h1 ping -c3 h2
mininet> xterm h1 h2
```

## 3) ตั้งค่า TBF บน h1 (Part B)
ภายใน xterm ของ h1:
```
h1# tc qdisc add dev h1-eth0 root tbf \
    rate <token_rate_kbit>kbit \
    burst <bucket_size_kbit>kbit \
    latency <latency_ms>ms

# ตรวจสอบค่าที่ตั้ง
h1# tc -s qdisc show dev h1-eth0
```

จำลอง Leaky Bucket ด้วย `tc` (ประมาณ, ใช้เทียบกับ TBF burst ใหญ่ — ไม่ใช่ strict):
```
h1# tc qdisc add dev h1-eth0 root tbf \
    rate <token_rate_kbit>kbit \
    burst 1600      # burst ขนาดเล็กมาก ~1 packet \
    latency <latency_ms>ms
```
> หมายเหตุ: นี่เป็นเพียงการประมาณ Leaky Bucket ด้วย TBF ของ Linux ถ้าต้องการ constant-rate
> output จริง ให้ implement เองด้วย `leaky_bucket_shaper.py` (Part D)

ลบ qdisc เพื่อ reset ก่อนทดลองรอบใหม่:
```
h1# tc qdisc del dev h1-eth0 root
```

## 4) Capture + สร้าง burst traffic (Part C)
```
# บน h2 (ก่อน apply TBF)
h2# tcpdump -i h2-eth0 -w before_shaping.pcap &

# บน h1 (รัน traffic generator)
h1# python3 generate_burst_traffic.py

# หยุด capture บน h2
h2# kill %1

# --- apply TBF ตาม Part B บน h1 แล้วรันซ้ำ ---

h2# tcpdump -i h2-eth0 -w after_shaping.pcap &
h1# python3 generate_burst_traffic.py
h2# kill %1
```

## 5) วิเคราะห์ด้วย Wireshark (Part E)
1. เปิด `before_shaping.pcap` และ `after_shaping.pcap`
2. Statistics → IO Graph → ตั้งค่า Y-axis เป็น **Bits/Tick**, interval **10 ms**
3. เปรียบเทียบกราฟทั้งสองไฟล์ — สังเกต pattern ของ throughput
4. บันทึกภาพกราฟทั้งสองไว้ในรายงาน
5. คำนวณ jitter: Statistics → Flow Graph หรือ export timestamp ด้วย
   File → Export Packet Dissections → As CSV แล้วคำนวณส่วนเบี่ยงเบนมาตรฐาน
   ของ inter-arrival time ด้วย Python/Excel

## ข้อควรระวัง
การทดลองนี้ทำใน Mininet (virtual network) เท่านั้น ห้ามนำเทคนิคสร้าง traffic
แบบ burst จำนวนมากไปทดสอบกับเครือข่ายจริงหรือเครือข่ายขององค์กรอื่นโดยไม่ได้รับอนุญาต
เนื่องจากอาจถูกตีความเป็นการโจมตีแบบ Denial of Service (DoS)
